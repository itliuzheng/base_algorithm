export const setUserInfo = ({commit},user,token) => {
  commit('userStatus',user,token);
}
// export const setToken = ({commit},token) => {
//   commit('tokenStatus',token);
// }
