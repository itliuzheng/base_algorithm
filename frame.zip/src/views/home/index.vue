<template>
  <div class="box-main">

  </div>
</template>
<script>

  export default {
    data(){
      return {
      }
    },
    create:function(){
    },
    methods:{

    }
  }
</script>
<style lang="scss">
</style>
<style lang="scss" scoped>
  $blue : #326CF1;
  $red : #F3464E;
  .box-main{
    padding: 20px 40px 40px;
  }

</style>
