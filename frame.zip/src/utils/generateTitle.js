export function generateTitle(title) {
  // $t :this method from vue-i18n, inject in @/lang/index.js
  // const hasKey = this.$te('route'+title)
  // const translateTitle = this.$t('route.'+title)
  //
  // if(hasKey){
  //   return translateTitle
  // }
  return title
}
